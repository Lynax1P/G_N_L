/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memset.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: csherill <csherill@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/04/21 00:26:01 by csherill          #+#    #+#             */
/*   Updated: 2021/04/23 01:01:54 by csherill         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memset(void *memptr, int val, size_t num)
{
	char		*buf;

	buf = (char *) memptr;
	while (num != 0)
	{
		*buf = (char) val;
		buf++;
		num--;
	}
	return (memptr);
}
