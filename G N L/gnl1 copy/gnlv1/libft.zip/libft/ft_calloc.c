/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_calloc.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: csherill <csherill@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/04/28 00:23:28 by csherill          #+#    #+#             */
/*   Updated: 2021/05/01 00:25:56 by csherill         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_calloc(size_t nmemb, size_t size)
{
	void	*calloc;	

	if (nmemb == (size_t)0 && size == (size_t)0)
	{
		nmemb = 1;
		size = 1;
	}
	calloc = malloc(size * nmemb);
	if (!calloc)
		return (NULL);
	ft_bzero(calloc, size * nmemb);
	return (calloc);
}
