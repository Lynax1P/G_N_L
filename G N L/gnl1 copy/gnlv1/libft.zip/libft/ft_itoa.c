/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_itoa.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: csherill <csherill@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/04/28 00:54:04 by csherill          #+#    #+#             */
/*   Updated: 2021/05/15 18:41:43 by csherill         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static long long	ft_countnum(long long n)
{
	long long	o;

	o = 0;
	while (n)
	{
		n = n / 10;
		o++;
	}
	return (o);
}

static char	*char_swap(char *arr)
{
	int		i;
	int		n;
	char	buf;

	i = 0;
	n = ft_strlen(arr) - 1;
	while (n)
	{
		if (i < n)
		{	
			buf = arr[i];
			arr[i] = arr[n];
			arr[n] = buf;
		}
		i++;
		n--;
	}
	return (&*(char *)arr);
}

static char	*ft_hellitoa(char *arr, long long count, long long nn, int flag)
{
	int			i;
	long long	nl;
	char		l;

	nl = 1;
	i = 0;
	if (flag > 0)
		count--;
	while (i < count)
	{
		l = (nn / nl) % 10 + 48;
		nl *= 10;
		arr[i] = l;
		i++;
	}
	if (flag > 0)
	{
		arr[i] = '-';
		i = i + flag;
	}
	arr[i] = '\0';
	arr = char_swap(arr);
	return (arr);
}

char	*ft_itoa(int n)
{
	long long	count;
	char		*itoa;
	long long	flag;
	long long	nn;

	if (n == 0)
		return (ft_strdup("0"));
	nn = (long long)n;
	flag = 0;
	if (flag == 0 && n < 0)
	{
		nn *= -1;
		flag++;
	}
	if (n != 0)
	{
		count = ft_countnum(nn) + flag;
		itoa = (char *)malloc(sizeof(char) * (count + 1));
		if (!itoa)
			return (NULL);
		return (ft_hellitoa(itoa, count, nn, flag));
	}
	else if (n == 0)
		return (NULL);
	return (NULL);
}
