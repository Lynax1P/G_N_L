/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: csherill <csherill@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/04/26 19:26:15 by csherill          #+#    #+#             */
/*   Updated: 2021/04/27 23:35:32 by csherill         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

size_t	ft_strlcat(char *dest, const char *src, size_t size)
{
	size_t	i;
	size_t	count;

	i = 0;
	count = 0;
	if (!src)
		return (i + ft_strlen(src));
	while (dest[i] && i < size)
		i++;
	if (size > 0)
	{
		while (size - 1 > i + count && src[count] != '\0')
		{
			dest[i + count] = src[count];
			count++;
		}
	}
	if (i < size)
		dest[i + count] = 0;
	return (i + ft_strlen(src));
}

// int main()
// {
// 	char *str = "14b dv ";
// 	char *strw = "14b dv ";
// 	char *stro = "w0";
// 	int d;
// 	int v;

// 	v = strlcat(stro, str, 12);
// 	d = ft_strlcat(strw, stro, 1);
// 	printf("%s\n", stro);
// 	printf("%s\n", strw);

// }
