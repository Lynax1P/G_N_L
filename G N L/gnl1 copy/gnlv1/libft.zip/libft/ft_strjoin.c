/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: csherill <csherill@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/05/01 01:27:43 by csherill          #+#    #+#             */
/*   Updated: 2021/05/15 18:42:42 by csherill         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strjoin(char const *s1, char const *s2)
{
	int		i;
	char	*str;
	char	*s;
	int		j;

	if (!s1 || !s2)
		return (NULL);
	i = ft_strlen(s1) + ft_strlen(s2);
	str = (char *)malloc(sizeof(char) * (i + 1));
	if (!str)
		return (NULL);
	s = (char *)s1;
	j = 0;
	while (i--)
	{
		if (s[j] == '\0')
		{
			s = (char *)s2;
			j = 0;
		}
		*str++ = s[j++];
	}
	*str = '\0';
	return (str - (ft_strlen(s1) + ft_strlen(s2)));
}
