/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlen.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: csherill <csherill@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/04/22 17:13:21 by csherill          #+#    #+#             */
/*   Updated: 2021/04/22 17:23:01 by csherill         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

size_t	ft_strlen(const char *s)
{
	size_t	n;

	n = 0;
	while (*s != '\0')
	{
		s++;
		n++;
	}
	return (n);
}

// #include <stdio.h>
// int main(int argc, char const *argv[])
// {
// 	int n;
// 	char a[] = "ssss";
// 	n = ft_strlen(a);
// 	printf("%d", n);
// 	return 0;
// }
