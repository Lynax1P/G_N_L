/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: csherill <csherill@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/04/21 21:03:53 by csherill          #+#    #+#             */
/*   Updated: 2021/04/25 19:54:28 by csherill         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memcpy(void *dest, const void *src, size_t n)
{
	unsigned char	*buf;
	unsigned char	*source;
	int				i;

	i = 0;
	buf = (unsigned char *)dest;
	source = (unsigned char *)src;
	if (!n || buf == source)
		return (buf);
	while (n--)
	{
		buf[i] = source[i];
		i++;
	}
	return ((void *) buf);
}
