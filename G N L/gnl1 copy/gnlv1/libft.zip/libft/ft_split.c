/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: csherill <csherill@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/05/04 02:17:02 by csherill          #+#    #+#             */
/*   Updated: 2021/05/15 18:42:29 by csherill         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static size_t	counting_lines(char const *arr, char c, size_t n, int i)
{
	int		flag;

	flag = 0;
	while (arr[i] != 0)
	{
		while (arr[i] != c && arr[i] !='\0')
		{
			i++;
			flag = 1;
		}
		if (flag == 1)
			n = n + 1;
		while (arr[i] == c && arr[i] !='\0')
			i++;
	}
	return (n);
}

static char	**freeio(char **l, int count)
{
	while (count >= 0)
	{
		free(l[count]);
		count = count - 1;
	}
	free(l);
	return (NULL);
}

static char	**splitic(char const *s, char c, char **lines, size_t i)
{
	int		j;
	int		k;
	int		count;

	count = 0;
	j = 0;
	while (i--)
	{
		k = 1;
		while (s[j] == c && s[j] != 0)
			j++;
		while (s[++j] != c && s[j] != 0)
			k++;
		lines[count] = (char *)malloc(sizeof(char) * (k + 1));
		if (!lines[count])
			return (freeio(lines, count));
		j = j - k;
		k = 0;
		while (s[j] != c && s[j] != 0)
			lines[count][k++] = s[j++];
		lines[count][k] = 0;
		count++;
	}
	lines[count] = 0;
	return (lines);
}

char	**ft_split(char const *s, char c)
{
	size_t		iOi;
	char		**lines;

	iOi = 0;
	if (!s)
		return (NULL);
	iOi = counting_lines(s, c, iOi, 0);
	if (iOi == 0)
	{
		lines = (char **)malloc(sizeof(char *) * (iOi + 1));
		if (!lines)
			return (NULL);
		*lines = 0;
		return (lines);
	}
	lines = (char **)malloc(sizeof(char *) * (iOi + 1));
	if (!lines)
		return (NULL);
	lines = splitic(s, c, lines, iOi);
	return (lines);
}
