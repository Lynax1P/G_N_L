/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: csherill <csherill@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/04/22 00:15:12 by csherill          #+#    #+#             */
/*   Updated: 2021/04/25 21:48:43 by csherill         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memchr(const void *s, int c, size_t n)
{
	int	i;

	i = 0;
	while (n != 0)
	{
		if (((unsigned char *) s)[i] == (unsigned char) c)
			return ((void *)&s[i]);
		i++;
		n--;
	}
	return (NULL);
}
