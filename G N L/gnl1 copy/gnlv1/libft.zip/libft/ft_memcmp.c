/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: csherill <csherill@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/04/25 03:52:31 by csherill          #+#    #+#             */
/*   Updated: 2021/05/12 22:18:56 by csherill         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int	ft_memcmp(const void *str1, const void *str2, size_t n)
{
	int				i;
	unsigned char	som1;
	unsigned char	som2;

	i = 0;
	while (n--)
	{
		som1 = *(unsigned char *) str1;
		som2 = *(unsigned char *) str2;
		if (som1 != som2)
			return (som1 - som2);
		str1++;
		str2++;
	}
	return (i);
}
