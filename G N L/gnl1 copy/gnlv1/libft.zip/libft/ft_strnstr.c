/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strnstr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: csherill <csherill@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/04/26 22:16:25 by csherill          #+#    #+#             */
/*   Updated: 2021/05/15 19:03:46 by csherill         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strnstr(const char *src, const char *search, size_t len)
{
	size_t	i;
	size_t	n;
	size_t	size;

	i = 0;
	n = 0;
	if (!*search)
		return (&*(char *)src);
	size = ft_strlen(search);
	while (len > i && src[i] != 0)
	{
		if (src[i] == search[n])
			while (src[i + n] == search[n] && (search[n] != 0) && \
				(src[i + n] != 0 ) && i + n < len)
				n++;
		if (size == n)
			return ((char *)&src[i]);
		n = 0;
		i++;
	}
	return (NULL);
}

// static	size_t	ft_search(char cc, char ss)
// {
// 	size_t	i;

// 	i = 0;
// 	if (cc == ss)
// 	{
// 		i = 1;
// 	}
// 	return (i);
// }

// static	void	ft_balans(int *s, int *d)
// {
// 	if (*s != *d)
// 	{
// 		*s = 0;
// 		*d = 0;
// 	}
// }	

// char	*ft_check(const char *src, const char *search, size_t len)
// {
// 	int		sch;
// 	int		flag;
// 	int		count;
// 	int		i;

// 	count = 0;
// 	sch = 0;
// 	flag = 0;
// 	i = 0;
// 	while (src[count] != 0 && len-- >= 0 && ft_strlen(search) > 0)
// 	{
// 		i = count;
// 		while (search[sch] != 0 && src[i] != 0)
// 		{
// 			if (ft_search(src[i], search[sch]) != 0)
// 				flag++;
// 			sch++;
// 			i++;
// 		}
// 		ft_balans(&flag, &sch);
// 		if ((size_t)sch == ft_strlen(search))
// 			return ((char *)&src[count - ft_strlen(search) + 1]);
// 		count++;
// 	}
// 	return (NULL);
// }

// char	*ft_strnstr(const char *src, const char *search, size_t len)
// {
// 	if (len > ft_strlen(src))
// 		len = ft_strlen(src);
// 	else if (len < 0)
// 		return (NULL);
// 	if (!ft_strlen(src) || (len < 0) || (ft_strlen(src) < ft_strlen(search)))
// 		return (NULL);
// 	if (ft_strlen(search) == 0)
// 		return (&*(char *)src);
// 	if (len > 0 && (int)ft_strlen(search) > 0 
// 		&& ft_strlen(src) >= ft_strlen(search))
// 		return (ft_check(src, search, len));
// 	return (NULL);
// }

// static void		ft_print_result(char const *s)
// {
// 	int		len;

// 	len = 0;
// 	while (s[len])
// 		len++;
// 	write(1, s, len);
// }

// int main()
// {
// 	char *a= "QqqQQQQQQQQQQQQQ3QQQQQQWE";
// 	char *b = "3";
// 	printf("%s\n",strnstr(a, b, -1));	
// //	ft_print_result("\n");
// 	printf("%s\n", ft_strnstr(a, b, -1));
// 	return 0;
// }
// static void		check_strnstr(char *big, char *little, int len)
// {
// 	const char *str;

// 	if (!(str = ft_strnstr(big, little, len)))
// 	{
// 		ft_print_result("NULL");
// 		ft_print_result(strnstr(big, little, len));
// 	}
// 	else
// 	{
// 		ft_print_result(0);
// 		ft_print_result(str);
// 		ft_print_result(strnstr(big, little, len));	
// 	}
// }

// int				main(int argc, const char *argv[])
// {
// 	int			arg;

// 	alarm(5);
// 	if (argc == 1)
// 		return (0);
// 	else if ((arg = atoi(argv[1])) == 1)
// 		check_strnstr("lorem ipsum dolor sit amet", "lorem", 15);
// 	else if (arg == 2)
// 		check_strnstr("lorem ipsum dolor sit amet", "ipsum", 15);
// 	else if (arg == 3)
// 		check_strnstr("lorem ipsum dolor sit lorem ipsum dolor", "ipsum", 35);
// 	else if (arg == 4)
// 		check_strnstr("lorem ipsum dolor sit amet", "", 10);
// 	else if (arg == 5)
// 		check_strnstr("lorem ipsum dolor sit amet", "ipsumm", 30);
// 	else if (arg == 6)
// 		check_strnstr("lorem ipsum dolor sit amet", "dol", 30);
// 	else if (arg == 7)
// 		check_strnstr("lorem ipsum dolor sit amet", "consectetur", 30);
// 	else if (arg == 8)
// 		check_strnstr("lorem ipsum dolor sit amet", "sit", 10);
// 	else if (arg == 9)
// 		check_strnstr("lorem ipsum dolor sit amet", "dolor", 15);
// 	else if (arg == 10)
// 		check_strnstr("lorem ipsum dolor sit amet", "dolor", 0);
// 	return (0);
// }
