/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncmp.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: csherill <csherill@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/04/20 22:26:01 by csherill          #+#    #+#             */
/*   Updated: 2021/04/25 03:47:59 by csherill         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int	ft_strncmp(const char *s1, const char *s2, size_t b)
{
	int	i;

	i = 0;
	while (b-- && ((unsigned char) s1[i] != '\0' \
		|| (unsigned char) s2[i] != '\0'))
	{
		if ((unsigned char) s1[i] - (unsigned char) s2[i] > 0)
			return (1);
		if ((unsigned char) s1[i] - (unsigned char) s2[i] < 0)
			return (-1);
		i++;
	}
	return (0);
}
