/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstmap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: csherill <csherill@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/05/11 03:30:18 by csherill          #+#    #+#             */
/*   Updated: 2021/05/15 19:00:13 by csherill         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include	"libft.h"

t_list	*ft_lstmap(t_list *list, void *(*f)(void *), void (*del)(void *))
{
	t_list	*p;
	t_list	*new;
	t_list	*tewp;

	if (!f || !list)
		return (NULL);
	new = ft_lstnew(f(list->content));
	if (!new)
		return (NULL);
	p = new;
	list = list->next;
	while (list != NULL)
	{
		tewp = ft_lstnew(f(list->content));
		if (!tewp)
		{
			ft_lstclear(&new, del);
			free(new);
		}
		p->next = tewp;
		p = p->next;
		list = list->next;
	}
	return (new);
}
