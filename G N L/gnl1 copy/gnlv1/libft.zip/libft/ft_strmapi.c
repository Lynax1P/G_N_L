/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strmapi.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: csherill <csherill@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/05/08 22:09:27 by csherill          #+#    #+#             */
/*   Updated: 2021/05/08 22:41:24 by csherill         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strmapi(char const *s, char (*f)(unsigned int, char))
{
	unsigned int	i;
	size_t			count;
	char			*line;

	if (!s || (!f))
		return (NULL);
	count = ft_strlen(s);
	line = (char *)malloc(sizeof(char) * (count + 1));
	if (!line)
		return (NULL);
	i = 0;
	while (s[i] != 0)
	{
		line[i] = f(i, s[i]);
		i++;
	}
	line[i] = 0;
	return (line);
}
