/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strtrim.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: csherill <csherill@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/05/03 22:39:08 by csherill          #+#    #+#             */
/*   Updated: 2021/05/15 18:43:31 by csherill         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static	int	len_left(char const *s1, char const *set)
{
	int		i;
	int		j;
	int		flag;

	i = 0;
	while (s1[i] != 0)
	{
		flag = 0;
		j = 0;
		while (set[j] != '\0')
		{
			if (s1[i] == set[j])
				flag++;
			j++;
		}
		if (flag == 0)
			return (i);
		i++;
	}
	return (i);
}

static	int	len_right(char const *s1, char const *set)
{
	int		i;
	int		j;
	int		flag;

	i = (int)ft_strlen(s1) - 1;
	while (i != 0)
	{
		flag = 0;
		j = 0;
		while (set[j] != '\0')
		{
			if (s1[i] == set[j])
				flag++;
			j++;
		}
		if (flag == 0)
			return (i + 1);
		i--;
	}
	return (i);
}

char	*ft_strtrim(char const *s1, char const *set)
{
	int		i;
	int		sum;
	char	*str;
	int		j;

	if (!s1)
		return (NULL);
	i = len_left(s1, set);
	sum = len_right(s1, set) - i;
	if (sum <= 0)
	{
		str = ft_calloc(0, 0);
		return (str);
	}
	str = (char *)malloc(sizeof(char) * (sum + 1));
	if (!str)
		return (NULL);
	j = 0;
	while (i != len_right(s1, set))
		str[j++] = s1[i++];
	str[j] = 0;
	return (str);
}
