/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_substr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: csherill <csherill@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/04/30 21:55:58 by csherill          #+#    #+#             */
/*   Updated: 2021/05/14 05:50:21 by csherill         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static	int	count(int j, unsigned int start, char const *s, size_t len)
{
	int		i;

	i = 0;
	if (j > (int)ft_strlen(s))
	{
		while (s[start] != '\0')
		{
			start++;
			i++;
		}
		return (i);
	}
	else if (len >= ft_strlen(s))
		return ((int)ft_strlen(s));
	return ((int)len);
}

char	*ft_substr(char const *s, unsigned int start, size_t len)
{
	int		i;
	char	*lol;
	int		j;

	if (!s)
		return (NULL);
	j = ft_strlen(s);
	i = 0;
	if ((int)start >= (int)ft_strlen(s))
		return (ft_calloc(sizeof(char), 1));
	j = j - len;
	i = count(j, start, s, len);
	lol = malloc(sizeof(char) * i + 1);
	if (!lol)
		return (NULL);
	i = 0;
	while (s[start] != '\0' && len > 0)
	{
		lol[i] = s[start];
		i++;
		start++;
		len--;
	}
	lol[i] = 0;
	return (lol);
}
