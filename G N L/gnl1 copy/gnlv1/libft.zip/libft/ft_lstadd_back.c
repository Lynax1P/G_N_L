/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstadd_back_bonus.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: csherill <csherill@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/05/11 01:46:40 by csherill          #+#    #+#             */
/*   Updated: 2021/05/11 04:31:41 by csherill         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	ft_lstadd_back(t_list **list, t_list *new)
{
	t_list	*lalist;

	if (!new)
		return ;
	else if (!*list)
	{
		*list = new;
		return ;
	}
	lalist = ft_lstlast(*list);
	lalist->next = new;
}
