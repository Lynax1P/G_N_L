/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstclear_bonus.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: csherill <csherill@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/05/11 03:12:41 by csherill          #+#    #+#             */
/*   Updated: 2021/05/11 04:37:40 by csherill         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	ft_lstclear(t_list **list, void (*del)(void*))
{
	t_list	*p;
	t_list	*well__;

	p = *list;
	while (p)
	{
		well__ = p->next;
		ft_lstdelone(p, del);
		p = well__;
	}
	*list = NULL;
}
