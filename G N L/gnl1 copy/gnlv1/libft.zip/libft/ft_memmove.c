/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memmove.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: csherill <csherill@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/04/21 23:45:16 by csherill          #+#    #+#             */
/*   Updated: 2021/05/12 22:20:02 by csherill         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memmove(void *dest, const void *src, size_t n)
{
	char		*dpt;
	const char	*spt;

	dpt = (char *) dest;
	spt = (const char *) src;
	if (dpt < spt)
	{
		while (n--)
		{
			*dpt++ = *spt++;
		}	
	}
	else if (dpt > spt)
	{
		while (n--)
			dpt[n] = spt[n];
	}
	return (dest);
}
