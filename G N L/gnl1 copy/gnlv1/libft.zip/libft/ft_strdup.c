/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: csherill <csherill@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/04/27 23:37:50 by csherill          #+#    #+#             */
/*   Updated: 2021/04/28 00:23:54 by csherill         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strdup(const char *s)
{
	char	*arr;
	int		len;

	len = ft_strlen(s) + 1;
	arr = malloc(sizeof(char) * len);
	if (!arr)
		return (NULL);
	ft_strlcpy(arr, s, len);
	return (arr);
}
