/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memccpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: csherill <csherill@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/04/21 23:26:05 by csherill          #+#    #+#             */
/*   Updated: 2021/04/25 20:59:38 by csherill         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memccpy(void *dest, const void *src, int c, size_t n)
{
	unsigned char	*buf;
	unsigned char	*source;
	unsigned char	ch;
	size_t			i;

	i = 0;
	buf = (unsigned char *)dest;
	source = (unsigned char *)src;
	ch = (unsigned char) c;
	while (n > i)
	{
		buf[i] = source[i];
		if (buf[i] == ch)
			return ((void *)(dest + i + 1));
		i++;
	}
	if (n == i)
		return (NULL);
	return (NULL);
}
