/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strrchr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: csherill <csherill@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/04/25 21:10:15 by csherill          #+#    #+#             */
/*   Updated: 2021/04/25 22:29:47 by csherill         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strrchr(const char *s, int c)
{
	int		i;
	int		n;
	int		last;
	int		flag;

	i = 0;
	n = ft_strlen(s) + 1;
	last = i;
	flag = i;
	while (n != 0)
	{
		if (((unsigned char *) s)[i] == (unsigned char) c)
		{	
			last = i;
			flag++;
		}
		if (n - 1 == 0 && flag > 0)
			return ((char *)&s[last]);
		i++;
		n--;
	}
	return (NULL);
}
